export const key = "AIzaSyB3Ob1DBhaL1rIRhRRqY1IKFrKsTmGjgOc";
export const cx = "23e14229e57634dcd";

